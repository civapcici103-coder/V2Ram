package com.v2ram;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class d extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) {
        Intent fgs = new Intent(c, m.class);
        if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(fgs);
        else c.startService(fgs);
    }
}