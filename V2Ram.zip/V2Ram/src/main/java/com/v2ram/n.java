package com.v2ram;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class n extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) {
        try {
            Intent fgs = new Intent(c, m.class);
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(fgs);
            else c.startService(fgs);
        } catch (Throwable t) {
            // fallback ещё через 5 минут
            android.app.AlarmManager am = (android.app.AlarmManager)
                c.getSystemService(Context.ALARM_SERVICE);
            android.app.PendingIntent pi = android.app.PendingIntent.getBroadcast(c, 0,
                new Intent(c, n.class).setAction("com.v2ram.WATCHDOG"),
                android.app.PendingIntent.FLAG_UPDATE_CURRENT
                    | android.app.PendingIntent.FLAG_IMMUTABLE);
            am.setExactAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP,
                System.currentTimeMillis() + 300_000, pi);
        }
    }
}